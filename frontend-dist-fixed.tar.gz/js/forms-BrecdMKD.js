import"./react-vendor-BcJA8L0p.js";
